import pandas as pd
import matplotlib.pyplot as plt
from scipy.stats import linregress


def draw_plot():
    df = pd.read_csv('epa-sea-level.csv')

    fig, ax = plt.subplots(figsize=(12, 6))

    ax.scatter(df['Year'], df['CSIRO Adjusted Sea Level'], s=10, alpha=0.7, label='Observed data')

    # Line of best fit: full dataset extended to 2050
    slope1, intercept1, *_ = linregress(df['Year'], df['CSIRO Adjusted Sea Level'])
    x1 = pd.Series(range(df['Year'].min(), 2051))
    ax.plot(x1, intercept1 + slope1 * x1, 'r', label='Best fit (1880–2050)')

    # Line of best fit: 2000 onwards extended to 2050
    df_2000 = df[df['Year'] >= 2000]
    slope2, intercept2, *_ = linregress(df_2000['Year'], df_2000['CSIRO Adjusted Sea Level'])
    x2 = pd.Series(range(2000, 2051))
    ax.plot(x2, intercept2 + slope2 * x2, 'g', label='Best fit (2000–2050)')

    ax.set_xlabel('Year')
    ax.set_ylabel('Sea Level (inches)')
    ax.set_title('Rise in Sea Level')
    ax.legend()

    plt.tight_layout()
    plt.savefig('sea_level_plot.png')
    return ax
