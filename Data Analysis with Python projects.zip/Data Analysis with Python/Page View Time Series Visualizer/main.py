import matplotlib
matplotlib.use('Agg')

from time_series_visualizer import draw_line_plot, draw_bar_plot, draw_box_plot
import unittest
from test_module import LinePlotTestCase, BarPlotTestCase, BoxPlotTestCase

# Generate plots
draw_line_plot()
draw_bar_plot()
draw_box_plot()
print("Plots saved: line_plot.png, bar_plot.png, box_plot.png")

# Run tests
loader = unittest.TestLoader()
suite = unittest.TestSuite()
suite.addTests(loader.loadTestsFromTestCase(LinePlotTestCase))
suite.addTests(loader.loadTestsFromTestCase(BarPlotTestCase))
suite.addTests(loader.loadTestsFromTestCase(BoxPlotTestCase))

runner = unittest.TextTestRunner(verbosity=2)
runner.run(suite)
