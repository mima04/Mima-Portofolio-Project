import pandas as pd
import matplotlib.pyplot as plt
import matplotlib.ticker as ticker
import seaborn as sns
from matplotlib.lines import Line2D

# Load and clean data
df = pd.read_csv('fcc-forum-pageviews.csv', index_col='date', parse_dates=True)

df = df[
    (df['value'] >= df['value'].quantile(0.025)) &
    (df['value'] <= df['value'].quantile(0.975))
]


def draw_line_plot():
    fig, ax = plt.subplots(figsize=(18, 6))

    df_copy = df.copy()
    ax.plot(df_copy.index, df_copy['value'], color='red', linewidth=0.8)

    ax.set_title('Daily freeCodeCamp Forum Page Views 5/2016-12/2019')
    ax.set_xlabel('Date')
    ax.set_ylabel('Page Views')

    fig.tight_layout()
    fig.savefig('line_plot.png')
    return fig


def draw_bar_plot():
    df_copy = df.copy()
    df_copy['year'] = df_copy.index.year
    df_copy['month'] = df_copy.index.month

    monthly_avg = (
        df_copy.groupby(['year', 'month'])['value']
        .mean()
        .unstack(level='month')
    )

    month_labels = [
        'January', 'February', 'March', 'April', 'May', 'June',
        'July', 'August', 'September', 'October', 'November', 'December'
    ]
    monthly_avg.columns = month_labels

    fig, ax = plt.subplots(figsize=(15, 7))
    monthly_avg.plot(kind='bar', ax=ax, width=0.8)

    ax.set_xlabel('Years')
    ax.set_ylabel('Average Page Views')
    ax.legend(title='Months', labels=month_labels)
    ax.set_xticklabels(monthly_avg.index, rotation=45)

    fig.tight_layout()
    fig.savefig('bar_plot.png')
    return fig


def draw_box_plot():
    df_copy = df.copy()
    df_copy.reset_index(inplace=True)
    df_copy['year'] = df_copy['date'].dt.year
    df_copy['month'] = df_copy['date'].dt.strftime('%b')
    df_copy['month_num'] = df_copy['date'].dt.month

    month_order = ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun',
                   'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec']

    fig, (ax1, ax2) = plt.subplots(1, 2, figsize=(18, 7))

    sns.boxplot(
        data=df_copy,
        x='year',
        y='value',
        ax=ax1,
        hue='year',
        palette='tab10',
        legend=False,
        flierprops=dict(marker='o', markersize=2, alpha=0.3)
    )
    ax1.set_title('Year-wise Box Plot (Trend)')
    ax1.set_xlabel('Year')
    ax1.set_ylabel('Page Views')

    sns.boxplot(
        data=df_copy,
        x='month',
        y='value',
        order=month_order,
        ax=ax2,
        hue='month',
        palette='tab10',
        legend=False,
        flierprops=dict(marker='o', markersize=2, alpha=0.3)
    )
    ax2.set_title('Month-wise Box Plot (Seasonality)')
    ax2.set_xlabel('Month')
    ax2.set_ylabel('Page Views')

    fig.tight_layout()
    fig.savefig('box_plot.png')
    return fig
