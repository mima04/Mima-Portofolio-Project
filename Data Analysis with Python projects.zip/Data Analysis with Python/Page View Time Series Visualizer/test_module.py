import unittest
import pandas as pd
import numpy as np
from time_series_visualizer import draw_line_plot, draw_bar_plot, draw_box_plot, df


class LinePlotTestCase(unittest.TestCase):
    def setUp(self):
        self.fig = draw_line_plot()
        self.ax = self.fig.axes[0]

    def test_line_plot_title(self):
        actual = self.ax.get_title()
        expected = "Daily freeCodeCamp Forum Page Views 5/2016-12/2019"
        self.assertEqual(actual, expected, "Expected line chart title to be 'Daily freeCodeCamp Forum Page Views 5/2016-12/2019'")

    def test_line_plot_xlabel(self):
        actual = self.ax.get_xlabel()
        self.assertEqual(actual, "Date", "Expected line chart xlabel to be 'Date'")

    def test_line_plot_ylabel(self):
        actual = self.ax.get_ylabel()
        self.assertEqual(actual, "Page Views", "Expected line chart ylabel to be 'Page Views'")

    def test_line_plot_data_quantity(self):
        actual = len(self.ax.lines[0].get_ydata())
        expected = len(df)
        self.assertEqual(actual, expected, "Expected number of data points in line chart to be equal to the number of rows in the dataframe")


class BarPlotTestCase(unittest.TestCase):
    def setUp(self):
        self.fig = draw_bar_plot()
        self.ax = self.fig.axes[0]

    def test_bar_plot_legend_labels(self):
        actual = [label.get_text() for label in self.ax.get_legend().get_texts()]
        expected = ['January', 'February', 'March', 'April', 'May', 'June',
                    'July', 'August', 'September', 'October', 'November', 'December']
        self.assertEqual(actual, expected, "Expected bar chart legend labels to be months of the year")

    def test_bar_plot_legend_title(self):
        actual = self.ax.get_legend().get_title().get_text()
        self.assertEqual(actual, "Months", "Expected bar chart legend title to be 'Months'")

    def test_bar_plot_xlabel(self):
        actual = self.ax.get_xlabel()
        self.assertEqual(actual, "Years", "Expected bar chart xlabel to be 'Years'")

    def test_bar_plot_ylabel(self):
        actual = self.ax.get_ylabel()
        self.assertEqual(actual, "Average Page Views", "Expected bar chart ylabel to be 'Average Page Views'")

    def test_bar_plot_number_of_bars(self):
        actual = len([rect for rect in self.ax.get_children() if hasattr(rect, 'get_height') and rect.get_height() > 0])
        # 4 years x 12 months = 48 bars (some months may be missing in edge years)
        self.assertGreater(actual, 0, "Expected bar chart to have bars")


class BoxPlotTestCase(unittest.TestCase):
    def setUp(self):
        self.fig = draw_box_plot()
        self.ax1 = self.fig.axes[0]
        self.ax2 = self.fig.axes[1]

    def test_box_plot_ax1_title(self):
        actual = self.ax1.get_title()
        self.assertEqual(actual, "Year-wise Box Plot (Trend)", "Expected box plot 1 title to be 'Year-wise Box Plot (Trend)'")

    def test_box_plot_ax2_title(self):
        actual = self.ax2.get_title()
        self.assertEqual(actual, "Month-wise Box Plot (Seasonality)", "Expected box plot 2 title to be 'Month-wise Box Plot (Seasonality)'")

    def test_box_plot_ax1_xlabel(self):
        actual = self.ax1.get_xlabel()
        self.assertEqual(actual, "Year", "Expected box plot 1 xlabel to be 'Year'")

    def test_box_plot_ax2_xlabel(self):
        actual = self.ax2.get_xlabel()
        self.assertEqual(actual, "Month", "Expected box plot 2 xlabel to be 'Month'")

    def test_box_plot_ax1_ylabel(self):
        actual = self.ax1.get_ylabel()
        self.assertEqual(actual, "Page Views", "Expected box plot 1 ylabel to be 'Page Views'")

    def test_box_plot_ax2_ylabel(self):
        actual = self.ax2.get_ylabel()
        self.assertEqual(actual, "Page Views", "Expected box plot 2 ylabel to be 'Page Views'")

    def test_box_plot_ax2_month_labels(self):
        actual = [label.get_text() for label in self.ax2.get_xticklabels()]
        expected = ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun',
                    'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec']
        self.assertEqual(actual, expected, "Expected month-wise box plot x-axis labels to start at Jan")


if __name__ == "__main__":
    unittest.main()
