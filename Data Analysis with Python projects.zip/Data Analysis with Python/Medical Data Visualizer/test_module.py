import unittest
import pandas as pd
import numpy as np
import medical_data_visualizer
from medical_data_visualizer import df


class CatPlotTestCase(unittest.TestCase):

    def setUp(self):
        self.fig = medical_data_visualizer.draw_cat_plot()
        self.ax = self.fig.axes[0]

    def test_line_plot_labels(self):
        actual = self.ax.get_xlabel()
        expected = 'variable'
        self.assertEqual(actual, expected, "Expected x-axis label: 'variable'")

    def test_bar_plot_number_of_bars(self):
        actual = len([rect for rect in self.ax.patches if rect.get_width() > 0 or rect.get_height() > 0])
        self.assertGreater(actual, 0, "Expected bars in the cat plot")

    def test_catplot_fig_has_two_axes(self):
        actual = len(self.fig.axes)
        self.assertEqual(actual, 2, "Expected 2 axes (one per cardio value)")


class HeatMapTestCase(unittest.TestCase):

    def setUp(self):
        self.fig = medical_data_visualizer.draw_heat_map()
        self.ax = self.fig.axes[0]

    def test_heat_map_shape(self):
        # After filtering, correlation matrix should be square
        actual = len(self.ax.get_xticklabels())
        self.assertGreater(actual, 0)

    def test_heat_map_values(self):
        # Check that the heatmap annotations exist
        texts = [t.get_text() for t in self.ax.texts]
        self.assertGreater(len(texts), 0, "Expected annotations in the heatmap")


class DataFrameTestCase(unittest.TestCase):

    def test_overweight_column_exists(self):
        self.assertIn('overweight', df.columns)

    def test_overweight_values(self):
        self.assertTrue(df['overweight'].isin([0, 1]).all(),
                        "Overweight column should only contain 0 or 1")

    def test_cholesterol_normalised(self):
        self.assertTrue(df['cholesterol'].isin([0, 1]).all(),
                        "Cholesterol should be normalised to 0 or 1")

    def test_gluc_normalised(self):
        self.assertTrue(df['gluc'].isin([0, 1]).all(),
                        "Gluc should be normalised to 0 or 1")


if __name__ == '__main__':
    unittest.main()
