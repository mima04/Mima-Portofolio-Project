import medical_data_visualizer
import unittest

# Generate charts
medical_data_visualizer.draw_cat_plot()
medical_data_visualizer.draw_heat_map()

# Run tests
loader = unittest.TestLoader()
suite = loader.discover('.', pattern='test_module.py')
unittest.TextTestRunner(verbosity=2).run(suite)
